# Sushma & Ramkrishna — Royal Engagement Countdown

A responsive, royal-maroon-and-gold engagement countdown website. It uses plain HTML, CSS and JavaScript and can be hosted free with GitHub Pages.

## 1. Set the correct engagement time

Open `script.js` and edit this line:

```js
const engagementTargetIST = "2026-12-13T18:00:00+05:30";
```

Replace `18:00:00` with the actual local engagement time in 24-hour format. The `+05:30` suffix is the India Standard Time offset.

Examples:
- 11:30 AM: `2026-12-13T11:30:00+05:30`
- 6:30 PM: `2026-12-13T18:30:00+05:30`

The date and time above are configured as 13 December 2026 at 6:00 PM IST as an editable example. Confirm the actual event time before publishing.

## 2. Preview on your device

Open `index.html` in a browser. For local development, you can also use Visual Studio Code with the Live Server extension.

## 3. Deploy free with GitHub Pages

1. Sign in at https://github.com.
2. Create a new **public** repository, for example `royal-engagement`.
3. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then save.
7. Wait for GitHub Pages to publish. Your public link will appear in the Pages settings and look like `https://YOUR-USERNAME.github.io/royal-engagement/`.

## Notes

- No paid hosting, database, backend, or build tools are required.
- The countdown calculates from the visitor's current device time and an explicit IST target timestamp. Visitors should have their device clock set correctly.
- The sample event venue and time should be checked and edited in `index.html` and `script.js` before sharing.
